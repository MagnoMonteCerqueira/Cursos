##################################################################
# Script: Discovery.fileserver.fs.ps1                              #
# Author: Danilo Barros de Medeiros                              #
# Contact: Email: danilo@provtel.com.br                          #
# Date: 2018-06-16                                               #
#                                                                #
# Script: Discovery.fileserver.fs.ps1                              #
# Author: Magno Monte Cerqueira                                  #
# Contact: magno.cerqueira@2mti.com.br                           #
# Date: 2019-02-16                                               #
#                                                                #
# Description: Monitoramento do Servidor de arquivos             #
#                                                                #
# Consultoria Zabbix           2mti soluções e serviços          # 
# http://www.provtel.com.br    http://treinamentos.2mti.com.br   #
##################################################################
#
# Versao 0.1
#
# NOME
#   Discovery.fileserver.ps1
#
# DESCRICAO
#   Efetua o a coleta de dados referente as pastas de rede.
#
#
#
# REQUISITOS
#    Validado para Powershell Versão 5.0 - Não foi testado em versões anteriores
#
#
# Controle de Versão
#  
#  Magno Monte Cerqueira - Idealizador do projeto de monitoramento servidor de arquivos.
# 
#  Danilo Barros     16/02/2019 - Criada funcao discovery para descobrir as pastas de rede em 
#                                  conjunto com a motagem do JSON para envio dos dados coletados para o zabbix.
#  
# NOTA
# Formas de execução do script 
#
# Discovery.fileserver.ps1
#
#
# 1 - Abra o Powershell como Administrador e execute o comando Set-ExecutionPolicy Unrestricted e confirme;
# 2 - Caso já tenha feito o procedimento acima no Host, desconsidere e pule para o próximo requerimento; 
# 3 - Inserir o arquivo DiscoveryProcess.ps1 no diretorio de sua escolha;
# 4 - Abra o powershell e navegue até o diretorio do script; 
#
# TESTES
#
# Parâmetro DISCOVERY - Realiza o discovery dos processos e monta o JSON.
#
# EX:    .\Discovery.fileserver.fs.ps1 DISCOVERYFS
#
#
# Parâmetro FSNOME + PASTA - coleta nome da pasta.
#
#
# EX:    .\Discovery.fileserver.fs.ps1 FSNOME Administrativo
#
#
#Parâmetro FSCACHE + PASTA - coleta o tipo de cache utilizado na pasta.
#
#
# EX:    .\Discovery.fileserver.fs.ps1 FSCACHE Administrativo
#
#
#Parâmetro LOCAL + PASTA - coleta o tipo de configuração da pasta.
#
#
# EX:    .\Discovery.fileserver.fs.ps1 FSTIPO Administrativo
#
#
# 
#  
#
# ARQUIVOS QUE COMPÕE ESSE PROJETO
#
# Discovery.fileserver.fs.ps1
# Template_Agente_Ativo_Monitoramento_FILE_SERVER_SHARE_ZABBIX_4.2_VERSAO-0.1
# discovery.filesever.fs.conf
# Dashboard Servidor de arquivos.json
# LEIA-ME.pdf
# 
#
###############################################################################################

# Inicio do Script Discovery.fileserver.fs.ps1;

# Para entrar na condição de Discovery o script aguarda uma passagem de parâmetros;

Param(
  [string]$DESCOBERTA,
  [string]$PASTA
)

# Descoberta em LLD
if ( $DESCOBERTA -eq 'DISCOVERYFS' )
{
#$comando = get-smbshare | select
$comando = get-smbshare | select
$2mti = 1
write-host "{"
write-host " `"data`":[`n"
foreach ($listao in $comando)
{
    if ($2mti -lt $comando.Count)
    {
        $line= "{ `"{#PASTASREDE}`":`"" + $listao.Name + "`" },"
        write-host $line
    }
    elseif ($2mti -ge $comando.Count)
    {
    $line= "{ `"{#PASTASREDE}`":`"" + $listao.Name + "`" }"
    write-host $line
    }
    $2mti++;
}
write-host
write-host " ]"
write-host "}"
}

#FUNÇÃO PARA COLETAR NOME DA PASTA 
if ($DESCOBERTA -eq 'FSNOME'){

get-smbshare | where {$_.Name -ccontains "$PASTA"} | select-object -ExpandProperty Name

}
#FUNÇÃO PARA COLETAR O STATUS DA PASTA 
if ($DESCOBERTA -eq 'FSSTATUS'){

get-smbshare | where {$_.Name -ccontains "$PASTA"} | select-object -ExpandProperty ShareState

}
#FUNÇÃO PARA COLETAR TIPO DA PASTA 
if ($DESCOBERTA -eq 'FSTIPO'){

get-smbshare | where {$_.Name -ccontains "$PASTA"} | select-object -ExpandProperty AvailabilityType

}

#FUNÇÃO PARA COLETAR TIPO SHARE DA PASTA 
if ($DESCOBERTA -eq 'FSSHTIPO'){

get-smbshare | where {$_.Name -ccontains "$PASTA"} | select-object -ExpandProperty ShareType 

}

#FUNÇÃO PARA COLETAR LOCAL DA PASTA 
if ($DESCOBERTA -eq 'FSLOCAL'){

get-smbshare | where {$_.Name -ccontains "$PASTA"} | select-object -ExpandProperty Path

}
#FUNÇÃO PARA COLETAR USUARIOS CONECTADOS DA PASTA 
if ($DESCOBERTA -eq 'FSUSUARIOS'){

get-smbshare | where {$_.Name -ccontains "$PASTA"} | select-object -ExpandProperty CurrentUsers 

}

#FUNÇÃO PARA COLETAR CACHE DA PASTA 
if ($DESCOBERTA -eq 'FSCACHE'){

get-smbshare | where {$_.Name -ccontains "$PASTA"} | select-object -ExpandProperty CachingMode

}

#FUNÇÃO PARA COLETAR QUANTIDADE DE ARQUIVOS NA PASTA 
if ($DESCOBERTA -eq 'FSQA'){
$executa = get-smbshare | where {$_.Name -ccontains "$PASTA"} | select-object -ExpandProperty Path
foreach ($object in $executa)
{
Get-ChildItem $object -Recurse  | Where-Object {!$_.PSIsContainer} | Measure-Object | select-object -ExpandProperty Count
}
}

#FUNÇÃO PARA COLETAR TAMANHO DA PASTA 
if ($DESCOBERTA -eq 'FSSIZE'){
$executa = get-smbshare | where {$_.Name -ccontains "$PASTA"} | select-object -ExpandProperty Path
foreach ($object in $executa)
{
(Get-ChildItem -path $object -recurse | Measure-Object -property length -sum ).sum
}
}



##################################################################
# Script: Discovery.fileserver.fs.ps1                              #
# Author: Danilo Barros de Medeiros                              #
# Contact: Email: danilo@provtel.com.br                          #
# Date: 2018-02-16                                               #
#                                                                #
# Script: Monitoramento servidor de arquivos                     #
# Author: Magno Monte Cerqueira                                  #
# Contact: magno.cerqueira@2mti.com.br                           #
# Date: 2019-06-16                                               #
#                                                                #
# Description: Monitoramento do servidor de arquivos             #
#                                                                #
# Consultoria Zabbix           2mti soluções e serviços          # 
# http://www.provtel.com.br    http://treinamentos.2mti.com.br   #
##################################################################